# Contact me on discord to buy the updated version. discord: cryonicx#9830

# Discord Spammer

You can use Advanced DISCORD SPAMMER with multiple tokens

# Images

![cryonicx](https://media.discordapp.net/attachments/880238900625432637/884169695220092968/dasd.PNG)




# Installation
İnstall requirements.txt 
````
pip3 install -r requirements.txt
````

# Tokens

Put your tokens inside of ``./assets/tokens.txt`` in this format

```
MzI1MTU3ODA5MjExNTcyMjI1.DOQYbA.vnBfE7DtN2zxZW6Ohw_POto6npA
MTYzODM3OTQ3OTY2MTI4MTI4.DOQApA.q-RZqUVpg2drGqpSjatcZf0EJZY
Mjc2MDY1OTc4MzM1NjI1MjE2.DNTGNw.cbNgca_1_9mJ9dal7bdnNkLcPxE
```


# Usage

Type ````python3 main.py```` to start the script.

# Developer

* *CRYONICX*

* Discord: [cryonicx](https://discord.com/users/690517771045437530)
* Github: [@CryonicX](https://github.com/CryonicsX)


# Show Your Support

If the project helped you, you can support me by giving ⭐️!

# License

Copyright © 2021 [CRYONICX](https://github.com/CryonicsX).<br />
This project is [MIT](https://github.com/CryonicsX/Discord-Spammer/blob/main/LICENSE) licensed.
